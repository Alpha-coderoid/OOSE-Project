<?php 
echo $_GET["Id"];
include_once "Function.php";
$donorObj=new donationDetails();
$donorObj->deleteDonationDetails($_GET["Id"]);
header("location:DonationDetailsListAll.php");

?>