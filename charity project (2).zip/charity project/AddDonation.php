<?php
include "Function.php";

$obj=new donation();
$obj->donationName=$_REQUEST["DonationName"];
//echo $_REQUEST["DonationName"];
echo $obj->donationName;
$obj->StoreDonation($obj->fileManagerObj);
//header("location:Donation.php");
?>