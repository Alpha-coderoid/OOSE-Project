<!DOCTYPE html>
<html>
<head>

</head>
<body>
<table border =1>
    <tr>
    <td>Donation ID</td>
        <td> Donor Id</td> 
        <td>Donation payment Method</td>
        <td>Type Of donation</td>
        <td>Amount Of Donation</td>
        <td>status</td>
        <td>Date Of Delivered</td>
        <td>Time</td>     
    </tr>
<?php
include_once "Function.php";
 $donatioObj=new donation();
   echo $_GET["Donid"];
   
   $h=$donatioObj->GetDonationFromFileByID($_GET["Donid"]);
   echo $h->donationName;
   echo "<br> <b> Details </b> <br>";
   for($i=0;$i<count($h->ArrayOfDonationDetails);$i++){
     // echo $h->ArrayOfDonationDetails[$i]->userId;
     echo "<tr>";
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->donationId;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->userId;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->paymentMethod;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->typeOfdonation;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->amountOfdonation;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->delivered;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->dateOfDeliveredDAY;
     echo "<td>";
     echo $h->ArrayOfDonationDetails[$i]->Time;
 
   }
 ?>
</table>
    </body>

</html>
 
