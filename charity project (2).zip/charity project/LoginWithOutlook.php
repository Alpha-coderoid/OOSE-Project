<?php
include_once "Ilogin.php";
class LoginWithOUTLOOK implements Ilogin 
{

    function dologin($email, $password){
        return  "login with OUTLOOK";

    }

}
?>
