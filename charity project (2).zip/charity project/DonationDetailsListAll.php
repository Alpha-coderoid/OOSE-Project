<!DOCTYPE html>
<html>
<head>

</head>
<body>
<table border =1>
    <tr>
    <td>Donation ID</td>
        <td> Donor Id</td> 
        <td>Donation payment Method</td>
        <td>Type Of donation</td>
        <td>Amount Of Donation</td>
        <td>status</td>
        <td>Date Of Delivered</td>
        <td>Time</td>
        <td>Delete</td>
        <td>UPDATE</td>

           
    </tr>
<?php
error_reporting(E_ALL & ~E_NOTICE);
include_once "Function.php";
$obj=new donationDetails();
$arr=array();
$arr=$obj->listAllDonationsDetails();

for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->donationId;
    echo "<td>";
    echo $arr[$i]->userId;
    echo "<td>";
    echo $arr[$i]->paymentMethod;
    echo "<td>";
    echo $arr[$i]->typeOfdonation;
    echo "<td>";
    echo $arr[$i]->amountOfdonation;
    echo "<td>";
    echo $arr[$i]->delivered;
    echo "<td>";
    echo $arr[$i]->dateOfDeliveredDAY;
    echo "<td>";
   // echo $arr[$i]->dateOfDeliveredMON;
   // echo "<td>";
    //echo $arr[$i]->dateOfDeliveredYear;
    echo $arr[$i]->Time;
    echo "<td>";
    echo "<a href=DeleteDnationDetails.php?Id=".$arr[$i]->donationId.">Delete </a>";
    echo "<td>";
    echo "<a href=FormUpdateDonationDetails?Id=".$arr[$i]->donationId.">UBDATE </a>";

   
}
?>
<tr>
    <td>
        <a href="AddDonationDetails.html"> Add User <a>

    </td>
</tr>
</table>
    </body>

</html>