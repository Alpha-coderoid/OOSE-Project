<?php
include "Function.php";
$obj=new donationDetails();
$obj->donationId=$_REQUEST["DonationID"];
    $obj->userId=$_REQUEST["DonorID"];
    $obj->paymentMethod=$_REQUEST["PaymentMethod"];
    $obj->typeOfdonation=$_REQUEST["typeofdonation"];
    $obj->amountOfdonation=$_REQUEST["amountofdonation"];
    $obj->delivered=$_REQUEST["statusofdonation"];
    $obj->dateOfDeliveredDAY=$_REQUEST["dateofdelivereddonation"];
   // $obj->dateOfDeliveredMON=$_REQUEST["dateofdelivereddonation"];
   // $obj->dateOfDelivereYear=$_REQUEST["dateofdelivereddonation"];
    $obj->Time=$_REQUEST["time"];

$obj->StoreDonationDetails($obj->fileManagerObj);
header("location:DonationDetailsListAll.php");

?>