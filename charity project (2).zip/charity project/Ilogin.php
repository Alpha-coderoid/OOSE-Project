<?php
interface Ilogin {

    function dologin($email, $password);
    
}

?>
