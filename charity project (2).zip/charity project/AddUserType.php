<?php
include "Function.php";
$obj=new UserType();


    $obj->userId=$_REQUEST["UserTypeID"];
    $obj->userType=$_REQUEST["UserType"];
    $obj->StoreUserType($obj->fileManagerObj);
    header("location:listUserType.php");


?>