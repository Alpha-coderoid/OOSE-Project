<?php 
include "Function.php";
//echo $_GET["Id"];
$obj=new DonationDetails();
$obj->donationId=$_REQUEST["DonationId"];
$obj->userId=$_REQUEST["userId"];
$obj->paymentMethod=$_REQUEST["PaymentMethod"];
$obj->typeOfdonation=$_REQUEST["TypeOfdonation"];
$obj->amountOfdonation=$_REQUEST["Amountofdonation"];
$obj->delivered=$_REQUEST["status"];
$obj->dateOfDeliveredDAY=$_REQUEST["date"];
$obj->Time=$_REQUEST["Time"];
//$obj->GetDonationFromFileByID($obj->donationId);
$obj->UpdateDonationDetails($obj->donationId,$obj);
header("location:DonationDetailsListAll.php");



?>