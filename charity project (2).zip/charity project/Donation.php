<!DOCTYPE html>
<html>
<head>

</head>
<body>
<table border =1>
    <tr>
        <td>Donation ID</td>
        <td> Donation name</td> 
        <td> Delete Donation</td> 
        <td> Update Donation</td> 


           
    </tr>
<?php
include_once "Function.php";
$obj=new donation();
$arr=array();
$arr=$obj->listAllDonations();
for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->donationId;
    echo "<td>";
    echo "<a href= DonationDetails.php?Donid=".$arr[$i]->donationId.">".$arr[$i]->donationName."</a>";
    echo "<td>";
    echo "<a href=deleteDonation.php?Id=".$arr[$i]->donationId.">Delete</a>";
    echo "<td>";
    echo "<a href=UpdateDonation.html?Id=".$arr[$i]->donationId.">Update</a>";

    echo"</td>";
    echo "</tr>";
   
   
}
?>
<tr>
    <td>
        <a href="FormAddDonation.html"> Add User <a>
    </td>
</tr>
</table>
    </body>

</html>