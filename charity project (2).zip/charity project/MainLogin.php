<?php
include_once "Ilogin.php";
include_once "LoginWithGoogle.php";
include_once "UserLogin.php";
include_once "LoginWithFacbook.php";
include_once "LoginWithOutlook.php";


//echo $_REQUEST["Account"];
if($_REQUEST["Account"]=="google account")
{
 $con = new Userlogin(new LoginWithGoogle());
 echo  $con->exeLog("basma",112);
 echo "<br>";
}

if($_REQUEST["Account"]=="facebook account")
{
    $con = new Userlogin(new LoginWithFaceBook);
    echo  $con->exeLog("basma",112);
    echo "<br>";
}
if($_REQUEST["Account"]=="outlook account")
{
    $con = new Userlogin(new LoginWithOUTLOOK);
    echo  $con->exeLog("basma",112);
    echo "<br>";
}
?>