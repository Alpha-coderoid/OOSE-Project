<?php
echo $_GET["Id"];
include_once "Function.php";

$donorObj=new UserType();
$donorObj->deleteUserType($_GET["Id"]);
header("location:listUserType.php");
?>