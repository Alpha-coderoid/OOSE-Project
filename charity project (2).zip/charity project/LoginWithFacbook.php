<?php
include_once "Ilogin.php";
class LoginWithFaceBook implements Ilogin 
{
    function dologin($email, $password){
        return  "login with facebook";

    }
}

?>