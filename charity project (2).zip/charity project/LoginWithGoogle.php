<?php


class LoginWithGoogle implements Ilogin 
{

    function dologin($email, $password){
        return  "login with google";

    }

}
?>