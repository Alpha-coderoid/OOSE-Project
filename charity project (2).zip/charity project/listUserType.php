<!DOCTYPE html>
<html>
<head>

</head>
<body>

<table border =1>
    <tr>
        <td>User ID</td>
        <td> User Type</td> 
            <td>Delete</td>
            <td>Ubdate</td>


           
    </tr>
<?php
include_once "Function.php";

$obj=new UserType();
$arr=[];
$arr=$obj->listAllUserType();

for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->userId;
    echo "<td>";
    echo $arr[$i]->userType;
    echo "<td>";
    echo "<a href=deleteUserType.php?Id=".$arr[$i]->userId.">Delete</a>";
    echo "<td>";
    echo "<a href=UpdateUserType.html?Id=".$arr[$i]->userId.">Update</a>";
    echo"</td>";
    echo "</tr>";
}
?>
<tr>
    <td>
        <a href="AddUserType.html"> Add Type User <a>
    </td>
</tr>
</table>
    </body>

</html>