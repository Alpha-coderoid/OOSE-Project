<?php
include_once "Ilogin.php";

class Userlogin {

    public $StrategyObj;
    
    public function __construct($Strategy)
    {
          $this->StrategyObj = $Strategy;
    }
 
    function exeLog($email, $password){
    
     $this->StrategyObj->dologin($email, $password);
     return $this->StrategyObj->dologin($email, $password);
 
    }
 
 }
?>