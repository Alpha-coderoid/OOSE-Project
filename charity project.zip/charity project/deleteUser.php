<?php 
echo $_GET["Id"];
include_once "Function.php";
$donorObj=new donor();
$donorObj->deleteUser($_GET["Id"]);
header("location:User.php");

?>