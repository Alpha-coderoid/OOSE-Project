<?php
//include "User.php";
session_start();


 $Email=$_REQUEST["Email"];
 $Password=$_REQUEST["Password"];
 if($Email=="basma@gmail.com" && $Password=="123")
 {
    $_SESSION["Email"]="basma@gmail.com";

 }
 else
 {
     echo("user name or password is wrong");
 }
 
?>