<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php
     

    session_start();
    echo $_SESSION["Email"];
    
  
?>
<table border =1>
    <tr>
        <td>User ID</td>
        <td> User name</td> 
            <td>User Age </td>
            <td>User Email</td>
            <td>password</td>
            <td>type of user</td>
            <td>Delete</td>
            <td>Update</td>


           
    </tr>
<?php
include_once "Function.php";
$obj=new donor();
$arr=[];
$arr=$obj->listAllDonors();

for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->id;
    echo "<td>";
    echo $arr[$i]->UserName;
    echo "<td>";
    echo $arr[$i]->UserAge;
    echo "<td>";
    echo $arr[$i]->email;
    echo "<td>";
    echo $arr[$i]->password;
    echo "<td>";
    echo $arr[$i]->type;
    echo "<td>";
    echo "<a href=deleteUser.php?Id=".$arr[$i]->id.">Delete</a>";
    echo"</td>";
    echo "</tr>";
   
   
}
?>
<tr>
    <td>
        <a href="Form.html"> Add User <a>
    </td>
</tr>
</table>
    </body>

</html>