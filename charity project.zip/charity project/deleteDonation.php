<?php 
echo $_GET["Id"];
include_once "Function.php";
$donorObj=new donation();
$donorObj->deleteDonation($_GET["Id"]);
header("location:Donation.php");

?>