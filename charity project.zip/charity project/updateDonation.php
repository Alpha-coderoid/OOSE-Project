<?php 
include "Function.php";
//echo $_GET["Id"];
$obj=new donation();
$obj->donationId=$_REQUEST["DonationId"];
$obj->donationName=$_REQUEST["DonationName"];
//echo $obj->donationId;
//$obj->GetDonationFromFileByID($obj->donationId);
echo $obj->donationName;
echo $obj->donationName;

$obj->UpdateDonation($obj->donationId,$obj);
header("location:Donation.php");



?>