<?php
include "Function.php";
$obj=new UserType();

if($_REQUEST["UserPassword"]==$_REQUEST["UserPassword2"])
{
    $obj->UserName=$_REQUEST["UserName"];
    $obj->UserAge=$_REQUEST["UserAge"];
    $obj->email=$_REQUEST["UserEmail"];
    $obj->password=$_REQUEST["UserPassword"];
    $obj->type=$_REQUEST["UserType"];
    $obj->StoreDonor($obj->fileManagerObj);
    header("location:User.php");

}
else{
    echo "check your password confirmation ";
}




?>