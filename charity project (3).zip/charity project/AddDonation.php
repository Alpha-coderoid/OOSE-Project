<?php
include "Function.php";

$obj=new donation();
$obj->DonorId=$_REQUEST["DonorId"];
$obj->donationName=$_REQUEST["DonationName"];
//echo $_REQUEST["DonationName"];
echo $obj->donationName;
$obj->StoreDonation($obj->fileManagerObj);
header("location:Donation.php");
?>