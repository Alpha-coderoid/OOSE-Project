<?php 
include "Function.php";
//echo $_GET["Id"];
$obj=new donation();
$obj->DonorId=$_REQUEST["DonorId"];
$obj->donationId=$_REQUEST["donationId"];
$obj->donationName=$_REQUEST["DonationName"];
//echo $obj->donationId;
//$obj->GetDonationFromFileByID($obj->donationId);
$obj->UpdateDonation($obj->DonorId,$obj);
header("location:Donation.php");



?>