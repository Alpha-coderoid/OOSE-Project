<?php
abstract class observer
{
    public $subject;
    public abstract function ubdate();
}

class subject
{
    private $state;
    private $observers = array();
    private $listOFobservers;

     public function getState ()
     {

         return $this->state;

     }
     public function  setState ($state)
     {

         $this->state=$state;
         $this->notifyAllObservers();

     }
     public function attach ($observer)
     {
         array_push($this->observers,$observer);
         
     }
     public function  notifyAllObservers ()
     {

        foreach($this->observers as $obs)
        {
            $obs->ubdate();
        }

     }
}

?>