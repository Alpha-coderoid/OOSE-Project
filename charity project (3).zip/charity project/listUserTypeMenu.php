<!DOCTYPE html>
<html>
<head>

</head>
<body>

<table border =1>
    <tr>
        <td>User ID</td>
        <td> User Type</td> 
            <td>Delete</td>
            <td>Ubdate</td>


           
    </tr>
<?php
include_once "Function.php";

$obj=new UserTypeMenu();
$arr=[];
$arr=$obj->listAllUserTypeMenu();
for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->UserId;
    echo "<td>";
    echo $arr[$i]->TypeId;
    echo "<td>";
    for($j=0;$j<count($arr->FunctionId);$j++)
    {
        echo $arr[$i]->FunctionId;

    }
    echo $arr[$i]->FunctionId;
    echo "<td>";
    echo "<a href=deleteUserType.php?Id=".$arr[$i]->UserId.">Delete</a>";
    echo "<td>";
    echo "<a href=UpdateUserType.html?Id=".$arr[$i]->UserId.">Update</a>";
    echo"</td>";
    echo "</tr>";
}
?>
<tr>
    <td>
        <a href="AddUserType.html"> Add Type User <a>
    </td>
</tr>
</table>
    </body>

</html>