
<?php
      include_once("headerDonor.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>

                      <form action="AddDonationDetails.php" method="POST">
    

    Donor ID <input type ="text" name ="DonorID">
    <br>
    Payment Method <input type ="text" name ="PaymentMethod">
    <br>
    type of donation <input type ="text" name = "typeofdonation">
    <br>
    amount of donation <input type ="text" name ="amountofdonation">
    <br>
    <!---
    status of donation <input type ="text" name ="statusofdonation">
    <br>
    date of delivered donation <input type ="date" name ="dateofdelivereddonation">
    <br>
    ---->
    time of donation <input type ="time" name ="time">
    <br>
    <input type="submit">
    <br>

</form>

</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 


