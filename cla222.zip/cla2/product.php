class Product
{
    public $prodId;
    public $prodName; 
    public $fileManagerObj;
    


    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="product.txt";
     $this->fileManagerObj->Sperator="~";
    }
    function UpdateProduct($id, $obj){ 
        $OldRecord=$this->fileManagerObj->getLineWithId($id); 
        $NewRecord=$obj->prodId."~".$obj->prodName;
        $this->fileManagerObj->UpdateRecored($this->FileName,$NewRecord,$OldRecord);
    }

    



    function deleteProduct($id){
        $record=$this->fileManagerObj->getLineWithId($id); 
        $this->fileManagerObj->deleteRecord($record);
    }
    function listAllProducts(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $res=  $this->GetProductFromFileByID($arrayline[0]); 
            if($res!=false)
                $myreturn[$i] =$res;
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
    function StoreProduct($fileManagerObj)
    {
         $id=$fileManagerObj->getLastId("~")+1;
         $record=$id."~".$this->prodName;
         $fileManagerObj->StoreRecordinFile($record);
    }
    
    function GetProductFromFileByID($id){
        $r=new Product();
        
        $record=$this->fileManagerObj->getLineWithId($id); 
        if($record!="")
        {
            $arrayline2=explode($this->fileManagerObj->Sperator,$record); 
            if($arrayline2[0]!="")
            { 
              $r->prodId= $arrayline2[0];
              $r->prodName= $arrayline2[1];
              return $r;

            }
        }
        return false;

       
    
    }

    function attach($observer)
    {
        array_push($this->observers,$observer);
    }

    function notifyAllObservers(){
        foreach($this->observers as $obs){
            $obs->dosomething();
        }
    }
}