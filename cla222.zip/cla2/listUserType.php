<?php
include_once("header.php");
?>



<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2><a href=listProducts.php>PRODUCTS</a></h2>
                      <H3><table border =1>
    
                      <table border =1>
    <tr>
        <td>User ID</td>
        <td> User Type</td> 
            <td>Delete</td>
            <td>Ubdate</td>


           
    </tr>
<?php
include_once "Functions.php";

$obj=new UserType();
$arr=[];
$arr=$obj->listAllUserType();

for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->userId;
    echo "<td>";
    echo $arr[$i]->userType;
    echo "<td>";
    echo "<a href=deleteUserType.php?Id=".$arr[$i]->userId.">Delete</a>";
    echo "<td>";
    echo "<a href=UpdateUserTypeForm.php?Id=".$arr[$i]->userId.">Update</a>";
    echo"</td>";
    echo "</tr>";
}
?>
<tr>
    <td>
        <a href="AddUserTypeForm.php"> Add Type User <a>
    </td>
</tr>
</table>
   

</table>
    </form>
    </body>

</html>

</H3></p>
                   
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                 
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
    
    
    <?php
include_once("footer.php");
?>







