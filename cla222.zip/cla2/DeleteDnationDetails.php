<?php 
echo $_GET["Id"];
include_once "Functions.php";
$donorObj=new donationDetails();
$donorObj->deleteDonationDetails($_GET["Id"]);
header("location:DonationDetailsListAll.php");

?>