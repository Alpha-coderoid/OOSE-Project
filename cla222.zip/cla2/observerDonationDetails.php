<?php

abstract class observer 
{
    public $subject;
  
   function alert()
   {
       echo"did something! ";
       //implementation here not important!!
     }
     
  
}

  class browser extends observer
  {
    function __construct($subject)
    {
        $this->subject=$subject;
        $this->subject->attach($this);
    }
    function alert(){
      
    }
}
      

  ?>