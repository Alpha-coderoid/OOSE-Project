
<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>


                      <form action="AddUserType.php" method="POST">
    <br> User Type ID <input type="text" name="UserTypeID" required>
    <br>
    <br> User Type <input type="text" name="UserType" required>
    <input type="submit">
    <br>

</form>
</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 


