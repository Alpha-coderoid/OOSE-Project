<?php
interface ilist
{
    function ListAll();
}