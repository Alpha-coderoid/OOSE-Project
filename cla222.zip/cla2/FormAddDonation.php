
<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>



                      <form action="AddDonation.php" method="POST">

    Donor ID <input type="text" name="DonorId">
    <br>Donoation ID <input type="text" name="DonationId">

    <br> Donation name <input type="text" name="DonationName">
    <br>
    <input type="submit">
    <br>


</form>

</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 




