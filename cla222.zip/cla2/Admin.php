<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2><a href=listProducts.php>PRODUCTS</a></h2>
                     
                  </div>
                  <div class="titlepage">
                      <h2><a href=listFunc.php>Menu</a></h2>
                     
                  </div>
                  <div class="titlepage">
                      <h2><a href=User.php>User</a></h2>
                     
                  </div>
                  <div class="titlepage">
                      <h2><a href=Donation.php>Donation</a></h2>
                     
                  </div>

                  <div class="titlepage">
                      <h2><a href=listUserType.php>User Type</a></h2>
                     
                  </div>
               </div>
               <div class="col-md-7">
                  
               </div>
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 