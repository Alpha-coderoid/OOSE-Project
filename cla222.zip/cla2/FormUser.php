



<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>

                      <form action="AddUser.php" method="POST">
    User name <input type ="text" name ="UserName" required>
    <br>
    User age <input type ="text"  name ="UserAge"required>
    <br>
    User email <input type ="text" name ="UserEmail"required>
    <br>
    User password <input type ="password" name ="UserPassword"required>
    <br>
    User type <input type ="text" name ="UserType"required>
    <br>
   confirm User password <input type ="password" name ="UserPassword2"required>
    <br>
    <input type="submit">
    <br>

</form>
</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 