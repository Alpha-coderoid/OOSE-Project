<?php
session_start();
//remove all session variables
//unset variable mo3ayan
session_unset();

session_destroy();
header("location:listp.php");
?>
