<?php

session_start();
 $Email=$_REQUEST["Email"];
 $Password=$_REQUEST["Password"];

 include_once("UserModel.php");
 $obj=NEW User();
 $loginTrueOrFalse=$obj->Login($Email,$Password);
 
 if($loginTrueOrFalse)
 {
    $_SESSION["Email"]=$Email;
    echo "Login Success";

 }
 else
 {
     echo("user name or password is wrong");
 }
 ?>