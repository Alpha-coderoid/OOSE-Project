<?php
echo $_GET["Id"];
include_once "Functions.php";

$donorObj=new UserType();
$donorObj->deleteUserType($_GET["Id"]);
header("location:listUserType.php");
?>