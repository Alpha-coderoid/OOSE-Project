<?php
var_dump  ($_REQUEST["DonSel"]);

include_once "product.php";
$donorObj=new Product();
$donorObj->deleteProduct($_GET["Id"]);


foreach($_REQUEST["DonSel"] as $myitem)
{
   // echo $myitem."<br>";
   $donorObj=new Product();
   $donorObj->deleteProduct($myitem);
    
}
header("location:listProducts.php");
?>