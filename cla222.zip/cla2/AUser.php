<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2><a href=DonationDetailsListAll.php>Make Donation</a></h2>
                     
                  </div>
                  
               </div>
               <div class="col-md-7">
                  
               </div>
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 