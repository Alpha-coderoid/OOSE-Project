<?php
session_start();


$Email=$_REQUEST["Email"];
//echo $Email;
$Password=$_REQUEST["Password"];
//echo $Password;
$f=0;
include_once("Functions.php");
$obj=NEW donor();

 $type = $obj->Login($Email,$Password,$type);

 if($type==1)
 {
    $_SESSION["Email"]=$Email;
  
    $f=1;
    header("location:Admin.php");
    echo "Login Success";
 }
 if($type==2)
 {
    $_SESSION["Email"]=$Email;
  
    $f=1;
    header("location:AUser.php");
    echo "Login Success";
 }
if($f==0)
 {
    echo $_SESSION["Email"]=$Email;
    echo("user name or password is wrong");

 }
 /*
 if($loginTrueOrFalse)
 {
    $_SESSION["Email"]=$Email;
    if($type==1)
    {
        header("location:listp.php");

    }

    echo "Login Success";
 }
 
 else
 {
    //echo $_SESSION["Email"]=$Email;
     echo("user name or password is wrong");
 }
 /*
if($Email=="farida.sherif@msa.edu.eg"&& $Password=="123")
{
    $_SESSION["Email"]=$Email;

    echo   $_SESSION["Email"];
    echo "correct Password";
}
else
{
   
}
*/

?>