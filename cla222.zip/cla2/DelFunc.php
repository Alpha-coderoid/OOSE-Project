<?php 
echo $_GET["Id"];
include_once "Menu.php";
$donorObj=new Func();
$donorObj->deleteFunc($_GET["Id"]);
header("location:listFunc.php");

?>