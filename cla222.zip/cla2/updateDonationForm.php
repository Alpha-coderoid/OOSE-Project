<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>

                      <form action="updateDonation.php" method="POST">

    DonorId <input type="number" name="DonorId" required>
    <br> Donation id
    <input type="number" name="donationId" required>
    <br> Donation Name<input type="text" name="DonationName" required>
    <br>
    <input type="submit">
    <br>
</form>
</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 









