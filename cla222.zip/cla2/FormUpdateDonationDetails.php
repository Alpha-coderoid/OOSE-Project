<?php
      include_once("headerDonor.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>

                      <form action="UPDATEDnationDetails.php" method="POST">
    
    Donation id  <input type ="number" name ="DonationId" required>
    <br>
    user id  <input type ="number" name ="userId" required>
    <br>
    Donation payment Method  <input type ="number" name ="PaymentMethod" required>
    <br>
    Type Of donation  <input type ="number" name ="TypeOfdonation" required>
    <br>
    Amount of donation <input type ="number" name ="Amountofdonation" required>
    <br>
    status <input type ="text" name ="status" required>
    <br>
    Date Of Delivered <input type ="date" name ="date" required>
    <br>
    Time<input type ="time" name ="Time" required>
    <br>
    <input type="submit">
    <br>

</form>

</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 






