<?php 
include "Functions.php";
//echo $_GET["Id"];
$obj=new Product();
$flag1=0;
$flag2=0;
$flag3=0;
if(is_numeric($_REQUEST["ProductName"]))
{
    header("location:UpdateProductForm.php");
    $flag1=1;

}

if( $_REQUEST["ProductId"]<0)
{
    $flag2=1;
    header("location:UpdateProductForm.php");


}
if( $_REQUEST["ProductName"]=="")
{
    $flag3=1;
    header("location:UpdateProductForm.php");


}

if($flag1==0 && $flag2==0 && $flag3==0 )
{
    $obj->prodId=$_REQUEST["ProductId"];
    $obj->prodName=$_REQUEST["ProductName"];
    $obj->UpdateProduct($obj->prodId,$obj);
    header("location:listProducts.php");
}
else
{
    echo "
    <script type=\"text/javascript\">
    alert(\"A new product has been added:\")
    </script>";
}



//echo $obj->donationId;
//$obj->GetDonationFromFileByID($obj->donationId);




?>