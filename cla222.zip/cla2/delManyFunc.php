<?php
var_dump  ($_REQUEST["DonSel"]);

include_once "Menu.php";
$FuncObj=new Func();
$FuncObj->deleteFunc($_GET["Id"]);


foreach($_REQUEST["DonSel"] as $myitem)
{
   // echo $myitem."<br>";
   $FuncObj=new Func();
   $FuncObj->deleteFunc($myitem);
    
}
header("location:listFunc.php");
?>