<?php

abstract class observer 
{
    public $subject;
  
   function alert()
   {
       echo"did something! ";
       //implementation here not important!!
     }
     
  
}

  class browser extends observer
  {
    function __construct($subject)
    {
        $this->subject=$subject;
        $this->subject->attach($this);
    }
    function alert(){
     
      

   include_once("Functions.php");
    $obj= new Product();
    $arr=[];
    $arr=$obj->listAllProducts();

    for($i=0;$i<count($arr);$i++)
    {
        $obj=$arr[$i];
    }
    $lastProduct=$obj->prodName;

 

      

      $myfile=fopen("notificationProduct.txt","r+") or die("Can't open");
      $lastId=0; 
       while(!feof($myfile))
      {
           $line=fgets($myfile);
           $arrayline = explode("~",$line);
           if($arrayline[0]!="")
           {
              $lastId=$arrayline[0];
           }
      }
      $lastId++;
      fclose($myfile);
     

      $myfile=fopen("notificationProduct.txt","a+") or die("Can't open");

      $obj=new donor();
      $arr=[];
      $arr=$obj->listAllDonors();


      for($i=0;$i<count($arr);$i++)
      {
          $obj=$arr[$i];
        $line=fgets($myfile);
        $arrayline = explode("~",$line);

        
        fwrite($myfile,"\r\n".$lastId."~"."A new product has been Added: ".$lastProduct."~".$obj->id);
       $lastId++;

      }
      fclose($myfile);
      echo "
      <script type=\"text/javascript\">
      alert(\"A new product has been added:$lastProduct\");
      </script>
  ";
     
     
       
      
  }
  }


?>