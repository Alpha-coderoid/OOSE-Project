<?php
include "Menu.php";
$obj=new Func();


if(is_numeric($_REQUEST["Name"]))
{
    header("location:FormFunctions.php");

}
else{
    $obj->Name=$_REQUEST["Name"];

    $obj->StoreFunc($obj->fileManagerObj);
    header("location:listFunc.php");

}






?>