<?php 
include "Functions.php";
//echo $_GET["Id"];
$obj=new donation();
$flag1=0;
$flag2=0;
$flag3=0;
$flag4=0;
$flag5=0;
if(is_numeric($_REQUEST["DonationName"]))
{
    header("location:updateDonationForm.php");
    $flag1=1;

}

if( $_REQUEST["DonorId"]<0)
{
    $flag2=1;
    header("location:updateDonationForm.php");


}
if(is_numeric($_REQUEST["donationId"]))
{
    header("location:updateDonationForm.php");
    $flag3=1;

}

if( $_REQUEST["donationId"]<0)
{
    $flag4=1;
    header("location:updateDonationForm.php");


}
if( $_REQUEST["DonationName"]=="")
{
    $flag5=1;
    header("location:updateDonationForm.php");


}

if( $flag1==0 && $flag2==0 && $flag3==0 && $flag4==0 && $flag5==0 )
{
    $obj->DonorId=$_REQUEST["DonorId"];
    $obj->donationId=$_REQUEST["donationId"];
    $obj->donationName=$_REQUEST["DonationName"];
    //echo $obj->donationId;
    //$obj->GetDonationFromFileByID($obj->donationId);
    $obj->UpdateDonation($obj->DonorId,$obj);
    header("location:Donation.php");
}







?>