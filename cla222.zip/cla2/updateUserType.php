<?php 
include "Functions.php";
$obj=new UserType();
$obj->userId=$_REQUEST["UserTypeId"];
$obj->userType=$_REQUEST["UserTypeName"];
$obj->UpdateUserType($obj->userId,$obj);
header("location:listUserType.php");



?>