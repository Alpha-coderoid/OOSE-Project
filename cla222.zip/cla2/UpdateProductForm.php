<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>
<form action="UpdateProduct.php" method="POST">
    
    Product id  <input type ="number" name ="ProductId">
    <br>
    Product name  <input type ="text" name ="ProductName">
    <br>
    <br>
    
    <input type="submit">
    <br>

</form>

</h2>
                     
                  </div>
                  <div class="titlepage">
                      <h2></h2>
                     
                  </div>
               </div>
               <div class="col-md-7">
                  
               </div>
            </div>
         </div>
      </div>

    </div>






<?php
      include_once("footer.php");
?> 
