<?php 
include "Menu.php";
//echo $_GET["Id"];
$obj=new Func();
$flag1=0;
$flag2=0;
if(is_numeric($_REQUEST["Name"]))
{
    header("location:UpdateFuncForm.php");
    $flag1=1;

}

if(is_numeric($_REQUEST["Id"]&& $_REQUEST["Id"]>0))
{
    

}
else
{
    $flag2=1;
    header("location:UpdateFuncForm.php");

}

if($flag1==0&&$flag2==0)
{
    $obj->Name=$_REQUEST["Name"];

    $obj->UpdatetFunc($obj->Id,$obj);
    $obj->Id=$_REQUEST["Id"];
    header("location:listFunc.php");
    header("location:listFunc.php");


}


//echo $obj->donationId;
//$obj->GetDonationFromFileByID($obj->donationId);






?>