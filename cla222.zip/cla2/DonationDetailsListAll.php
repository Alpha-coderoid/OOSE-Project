


<?php include_once("headerDonor.php")
?>
<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>Donation Details</a></h2>
                      <H3><table border =1>
    


                      <table border =1>
    <tr>
    <td>Donation ID</td>
        <td> Donor Id</td> 
        <td>Donation payment Method</td>
        <td>Type Of donation</td>
        <td>Amount Of Donation</td>
        <td>status</td>
        <td>Date Of Delivered</td>
        <td>Time</td>
        <td>Delete</td>
        <td>UPDATE</td>

           
    </tr>
<?php
error_reporting(E_ALL & ~E_NOTICE);
include_once "Functions.php";
$obj=new donationDetails();
$arr=array();
$arr=$obj->listAllDonationsDetails();

for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->donationId;
    echo "<td>";
    echo $arr[$i]->userId;
    echo "<td>";
    echo $arr[$i]->paymentMethod;
    echo "<td>";
    echo $arr[$i]->typeOfdonation;
    echo "<td>";
    echo $arr[$i]->amountOfdonation;
    echo "<td>";
    echo $arr[$i]->delivered;
    echo "<td>";
    echo $arr[$i]->dateOfDeliveredDAY;
    echo "<td>";
   // echo $arr[$i]->dateOfDeliveredMON;
   // echo "<td>";
    //echo $arr[$i]->dateOfDeliveredYear;
    echo $arr[$i]->Time;
    echo "<td>";
    echo "<a href=DeleteDnationDetails.php?Id=".$arr[$i]->donationId.">Delete </a>";
    echo "<td>";
    echo "<a href=FormUpdateDonationDetails.php?Id=".$arr[$i]->donationId.">UPDATE </a>";

   
}
?>
<tr>
    <td>
        <a href="AddDonationDetailsForm.php"> Add donation <a>

    </td>
</tr>
</table>
   

</table>
    </form>
    </body>

</html>

</H3></p>
                   
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                 
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
    
    




    <?php include_once("footer.php")
?>









