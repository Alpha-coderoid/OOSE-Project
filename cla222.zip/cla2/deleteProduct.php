<?php 
//echo $_GET["Id"];
include_once "Functions.php";
$donorObj=new Product();
$donorObj->deleteProduct($_GET["Id"]); 
header("location:listProducts.php");



?>