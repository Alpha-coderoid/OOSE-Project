<?php
include_once("header.php");
?>



<!DOCTYPE html>
<html>
<head>

</head>
<body>
    <form action="delManyProducts.php" method="post">
<?php
  

   
 
   
  //  echo $_SESSION["Email"];
?>

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2><a href=listProducts.php>PRODUCTS</a></h2>
                      <H3><table border =1>
    <tr>
        <td>Select</td>
        <td>product ID</td>
        <td>product Name</td> 
        <td>Delete</td> 
        <td>Update</td> 
        
           

           
    </tr>
<?php

include_once "Functions.php";
$obj=new Product();
$arr=[];
$arr=$obj->listAllProducts();

for($i=0;$i<count($arr);$i++)
{
 
   
    echo "<tr><td><input type=checkbox name=DonSel[] value=". $arr[$i]->prodId."></td>";
   
 
  
   
    echo "<td>";
    echo $arr[$i]->prodId;
    echo"</td>";
    echo"<td>";
    echo $arr[$i]->prodName;
    echo "</td>";
    echo"<td>";
    
    echo "<a href=deleteProduct.php?Id=".$arr[$i]->prodId.">Delete</a>";
    echo"</td>";
    echo "<td>";
     echo "<a href=UpdateProductForm.php> UpdateProduct <a>";
    echo"</td>";
    echo "</tr>";
  
   
   
}

?>
<tr>
    <td>
        <a href="FormProduct.php"> Add <a>
            <input type="submit" value="Delete All Selected">
    </td>
    
</tr>

   

</table>
    </form>
    </body>

</html>

</H3></p>
                   
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                 
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
    
    <?php
include_once("footer.php");
?>