<?php
$DonationName=$_REQUEST["DonationName"];
var_dump($_FILES);
$target_dir= "images/";
$target_file= $target_dir . basename($_FILES["DonationImageFile"]["name"]);
if(move_uploaded_file($_FILES["DonationImageFile"]["tmp_name"],$target_file))
{
    echo "the file has been upploaded";
}

$myfile=fopen("Donation.txt","r+") or die("Can't open");
$lastId=0; 
 while(!feof($myfile))
{
     $line=fgets($myfile);
     $arrayline = explode("~",$line);
     if($arrayline[0]!="")
     {
        $lastId=$arrayline[0];
     }
}
 

$lastId++;
$record = $lastId."~".$DonationName."~".$target_file;
echo $record;
$myfile=fopen("Donation.txt","a+") or die("Can't open");
fwrite($myfile,"\r\n".$record);
fclose($myfile);
?>