<?php
include_once("header.php");
?>


<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>Donations</h2>
                      <H3><table border =1>
    
                      <table border =1>
    <tr>
        <td> Donor ID</td> 
        <td>Donation ID</td>
        <td> Donation name</td> 
        <td> Delete Donation</td> 
        <td> Update Donation</td> 


           
    </tr>
<?php
include_once "Functions.php";
$obj=new donation();
$arr=array();
$arr=$obj->listAllDonations();
for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->DonorId;
    echo "<td>";
    echo $arr[$i]->donationId;
    echo "<td>";
    echo "<a href= DonationDetails.php?Donid=".$arr[$i]->DonorId.">".$arr[$i]->donationName."</a>";
    echo "<td>";
    echo "<a href=deleteDonation.php?Id=".$arr[$i]->DonorId.">Delete</a>";
    echo "<td>";
    echo "<a href=UpdateDonationForm.php?Id=".$arr[$i]->DonorId.">Update</a>";

    echo"</td>";
    echo "</tr>";
   
   
}
?>
<tr>
    <td>
        <a href="FormAddDonation.php"> Add Donation <a>
    </td>
</tr>
</table>
    </body>

   

</table>
    </form>
    </body>

</html>

</H3></p>
                   
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                 
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
    

<?php
include_once("footer.php");
?>

