<?php
      include_once("header.php");
?> 

<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>

                      <form action="updateUserType.php" method="POST">

    Donation id <input type="number" name="UserTypeId" required>
    <br> Donation name <input type="text" name="UserTypeName" required>
    <br>
    <input type="submit">
    <br>

</form>
</h2></h2>
                     
                  </div>
                
               </div>
            
            </div>
         </div>
      </div>

    </div>



<?php
      include_once("footer.php");
?> 


