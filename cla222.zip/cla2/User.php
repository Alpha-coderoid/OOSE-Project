<?php
include_once("header.php");
?>


<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2>Users</h2>
                      <H3><table border =1>
    
                      <table border =1>
    <tr>
        <td>User ID</td>
        <td> User name</td> 
            <td>User Age </td>
            <td>User Email</td>
            <td>password</td>
            <td>type of user</td>
            <td>Delete</td>
            <td>Update</td>


           
    </tr>
<?php
include_once "Functions.php";
$obj=new donor();
$arr=[];
$arr=$obj->listAllDonors();

for($i=0;$i<count($arr);$i++)
{
    echo "<tr>";
    echo "<td>";
    echo $arr[$i]->id;
    echo "<td>";
    echo $arr[$i]->UserName;
    echo "<td>";
    echo $arr[$i]->UserAge;
    echo "<td>";
    echo $arr[$i]->email;
    echo "<td>";
    echo $arr[$i]->password;
    echo "<td>";
    echo $arr[$i]->type;
    echo "<td>";
    echo "<a href=deleteUser.php?Id=".$arr[$i]->id.">Delete</a>";
    echo "<td>";
    echo "<a href=UpdateUserForm.php?Id=".$arr[$i]->id.">Update</a>";
    echo"</td>";
    echo"</td>";
    echo "</tr>";
   
}
?>
<tr>
    <td>
        <a href="FormUser.php"> Add User <a>
    </td>
</tr>
</table>
    </body>

</html>

   

</table>
    </form>
    </body>

</html>

</H3></p>
                   
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                 
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
    
    




<?php
include_once("footer.php");
?>

