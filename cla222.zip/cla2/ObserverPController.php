<?php
include_once("ObserverProduct.php");
include_once "Functions.php";
$obj=new Product();
$arr=[];
$arr=$obj->listAllProducts();


for($i=0;$i<count($arr);$i++)
{
    $obj=$arr[$i];
}
 

$browserRef =new browser($obj);
$browserRef->alert();
echo "
<script type=\"text/javascript\">
alert(\"A new product has been added:$lastProduct\");
</script>
";

header("location:listProducts.php");
?>

