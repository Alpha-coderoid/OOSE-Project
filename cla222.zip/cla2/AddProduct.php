<?php
include "Functions.php";



  
if(is_numeric($_REQUEST["ProductName"])||$_REQUEST["ProductName"]==" ")
{
    header("location:FormProduct.php");
   

}
else
{
   

    $obj=new Product();
    $obj->prodName=$_REQUEST["ProductName"];
    $obj->storeProduct($obj->fileManagerObj);
    header("location:ObserverPController.php");
  
}











?>