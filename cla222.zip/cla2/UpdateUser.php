<?php 

include "Functions.php";
$obj=new Donor();
$obj->id=$_REQUEST["UserID"];
$obj->UserName=$_REQUEST["UserName"];
$obj->UserAge=$_REQUEST["UserAge"];
$obj->email=$_REQUEST["UserEmail"];
$obj->password=$_REQUEST["UserPassword"];
$obj->type=$_REQUEST["UserType"];
$obj->UpdateUser($obj->id,$obj);
header("location:User.php");
?>


