<?php
//error_reporting(E_ALL & ~E_NOTICE);

class User {
    public $id;
    public $UserName; 
    public $UserAge; 
    public $email;
    public $password;
    public $type;
    public $fileManagerObj;
}

/*function Abstract perant()
{
    $record=$this->fileManagerObj->getLineWithId($id); 
    $arrayline2=explode($this->fileManagerObj->Sperator,$record); 

}*/ 
class recipient extends User{

}
class Accountant extends User{

}
class Admin extends User{

}
class warehouseManager extends User{

}
class Volunteer extends User{


}
class UserType{

    public $userId;
    public $userType;
    public $fileManagerObj;

    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="UserType.txt";
     $this->fileManagerObj->Sperator="~";
    }
    function StoreUserType($fileManagerObj)
    {
         $id=$fileManagerObj->getLastId("~")+1;
         $record=$this->userId."~".$this->userType;
         $fileManagerObj->StoreRecordinFile($record);
    }
    function listAllUserType(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $rec= $this->GetUserTypeFromFileByID($arrayline[0]); 
            if($rec!=false)
            {
               $myreturn[$i] = $rec; 
            }
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
     function GetUserTypeFromFileByID($id){
        $r=new  UserType();
        $record=$this->fileManagerObj->getLineWithId($id); 
        $arrayline2=explode($this->fileManagerObj->Sperator,$record); 
        if($arrayline2[0]!="")
        {  $r->userId= $arrayline2[0];
            $r->userType= $arrayline2[1];
            return $r;
        }
        else
        {
            return false;
        }
      
    }
    function deleteUserType($id){
        $record=$this->fileManagerObj->getLineWithId($id); 
        $this->fileManagerObj->deleteRecord($record);
    }

    function UpdateUserType($id, $obj){
        $OldRecord=$this->fileManagerObj->getLineWithId($id); 
        $NewRecord=$obj->userId."~".$obj->userType. "\r\n";
        $this->fileManagerObj->UpdateRecored($this->FileName,$NewRecord,$OldRecord);
    }
    


}
class UserTypeMenu
{

    public $UserId;
    public $TypeId;
    public $FunctionId;

    public $fileManagerObj;

    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="UserTypeMenu.txt";
     $this->fileManagerObj->Sperator="~";
    }
    function listAllUserTypeMenu(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $rec= $this->GetUserTypeMenuFromFileByID($arrayline[0]); 
            if($rec!=false)
            {
               $myreturn[$i] = $rec; 
            }
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
     function GetUserTypeMenuFromFileByID($id){
        $r=new  UserTypeMenu();
        $record=$this->fileManagerObj->getLineWithId($id); 
        $arrayline2=explode($this->fileManagerObj->Sperator,$record); 
        if($arrayline2[0]!="")
        {  $r->UserId= $arrayline2[0];
            $r->TypeId= $arrayline2[1];
            $r->FunctionId= $arrayline2[2];
            return $r;
        }
        else
        {
            return false;
        }
      
    }
}

class donor extends User {
    

    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="UserDetails.txt";
     $this->fileManagerObj->Sperator="~";
    }
    
    function Login($Email,$Password,$type)
    {
        //$myreturn=new User;
      //  include_once "product.php";
            $obj=new donor();
            $arr=[];
            $arr=$obj->listAllDonors();


            //echo"helooooooooooo";
        for($i=0;$i<count($arr);$i++)
        {
           
           
            if($arr[$i]->email==$Email&&$arr[$i]->password==$Password)
            {

                echo $arr[$i]->email;
                echo $arr[$i]->password;
                echo "helooooooooooo";
                $type =$arr[$i]->type;
                return $type;

            }


        }

      

               
           
      
        
        
    }
    function UpdateUser($id, $obj){
        $OldRecord=$this->fileManagerObj->getLineWithId($id); 
        $NewRecord=$obj->id."~".$obj->UserName."~".$obj->UserAge."~".$obj->email."~".$obj->password."~".$obj->type. "\r\n";
        $this->fileManagerObj->UpdateRecored($this->FileName,$NewRecord,$OldRecord);
    }
    
    function deleteUser($id){
        $record=$this->fileManagerObj->getLineWithId($id); 
        $this->fileManagerObj->deleteRecord($record);
    }
    function listAllDonors(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $rec= $this->GetDonorFromFileByID($arrayline[0]); 
            if($rec!=false)
            {
               $myreturn[$i] = $rec; 
            }
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
    function StoreDonor($fileManagerObj)
    {
         $id=$fileManagerObj->getLastId("~")+1;
         $record=$id."~".$this->UserName."~".$this->UserAge."~".$this->email."~".$this->password."~".$this->type;
         $fileManagerObj->StoreRecordinFile($record);
    }
    
    function GetDonorFromFileByID($id){
        $r=new donor();
        $record=$this->fileManagerObj->getLineWithId($id); 
        $arrayline2=explode($this->fileManagerObj->Sperator,$record); 
        if($arrayline2[0]!="")
        {  $r->id= $arrayline2[0];
            $r->UserName= $arrayline2[1];
            $r->UserAge= $arrayline2[2];
            $r->email= $arrayline2[3];
            $r->password= $arrayline2[4];
            $r->type= $arrayline2[5];
            return $r;
        }
        else
        {
            return false;
        }
      
    }
}


class Product
{
    public $prodId;
    public $prodName; 
    public $fileManagerObj;
    


    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="product.txt";
     $this->fileManagerObj->Sperator="~";
    }
    function UpdateProduct($id, $obj){ 
        $OldRecord=$this->fileManagerObj->getLineWithId($id); 
        $NewRecord=$obj->prodId."~".$obj->prodName;
        $this->fileManagerObj->UpdateRecored($this->FileName,$NewRecord,$OldRecord);
    }

    



    function deleteProduct($id){
        $record=$this->fileManagerObj->getLineWithId($id); 
        $this->fileManagerObj->deleteRecord($record);


      
    }
    function listAllProducts(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $res=  $this->GetProductFromFileByID($arrayline[0]); 
            if($res!=false)
                $myreturn[$i] =$res;
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
    function StoreProduct($fileManagerObj)
    {
         $id=$fileManagerObj->getLastId("~")+1;
         $record=$id."~".$this->prodName;
         $fileManagerObj->StoreRecordinFile($record);
    }
    
    function GetProductFromFileByID($id){
        $r=new Product();
        
        $record=$this->fileManagerObj->getLineWithId($id); 
        if($record!="")
        {
            $arrayline2=explode($this->fileManagerObj->Sperator,$record); 
            if($arrayline2[0]!="")
            { 
              $r->prodId= $arrayline2[0];
              $r->prodName= $arrayline2[1];
              return $r;

            }
        }
        return false;

       
    
    }

    function attach($observer)
    {
        array_push($this->observers,$observer);
    }

    function notifyAllObservers(){
        foreach($this->observers as $obs){
            $obs->dosomething();
        }
    }
}
class FileManager {
    public $FileName;
    public $Sperator;
    
    function DrawTable()
    {
       
       $myfile=fopen($this->FileName,"r+") or die("unable to open file");
       while(!feof($myfile))
       {
           $line=fgets($myfile);
           echo "<tr>";
           $arrayline=explode($this->Sperator,$line); 
           for($i=0; $i< count($arrayline);$i++)
           {
             echo "<td>". $arrayline[$i]. "</td>"; 
           }
          echo "</tr>";  
       }
       fclose($myfile);
    }
    function searchUser($filename,$search)
    {
        $myfile=fopen($filename,"r+") or die("unable to open file!");
        while(!feof($myfile)){
           $line=fgets($myfile);
           $i=strpos($line,$search);
           if($i>=0 && $i!=null)
           {
               return $line;
           }
           fclose($myfile);
           return False;
        }
    }
    function UpdateRecored($FileName,$NewRecord,$OldRecord){
        $contents = file_get_contents($this->FileName);
        $contents= str_replace($OldRecord,$NewRecord,$contents);
        file_put_contents($this->FileName,$contents);
    }
    function deleteRecord($record)
    {
        $contents = file_get_contents($this->FileName);
        $contents= str_replace("\r\n".$record,'',$contents);
        file_put_contents($this->FileName,$contents);
    }
   function getLastId() {
   
      $myfile=fopen($this->FileName,"r+") or die("Can't open");
      $lastId=0; 
       while(!feof($myfile))
      {
           $line=fgets($myfile);
           $arrayline = explode($this->Sperator,$line);
           if($arrayline[0]!="")
           {
              $lastId=$arrayline[0];
           }
      }
       return $lastId;
   }
   function getLineWithId($id){
      $myfile=fopen($this->FileName,"r+") or die("Can't open");
       while(!feof($myfile))
      {
           $line=fgets($myfile);
           $arrayline = explode($this->Sperator,$line);
           if($arrayline[0]==$id)
           {
              return $line ;
           }
      }
       return "";
   }
   function StoreRecordinFile($record){
   

   
        $myfile=fopen($this->FileName,"a+") or die("Can't open");
        fwrite($myfile,"\r\n".$record);
        fclose($myfile);
  
  
   }
}



   class donation{
    public $DonorId;
    public $donationId;
    public $donationName;
    public $ArrayOfDonationDetails;
    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="Donation2.txt";
     $this->fileManagerObj->Sperator="~";
    }
    function UpdateDonation($id, $obj){
        $OldRecord=$this->fileManagerObj->getLineWithId($id); 
        $NewRecord=$obj->DonorId."~".$obj->donationId."~".$obj->donationName;
        $this->fileManagerObj->UpdateRecored($this->FileName,$NewRecord,$OldRecord);
    }
    function deleteDonation($id){
        $record=$this->fileManagerObj->getLineWithId($id); 
        $this->fileManagerObj->deleteRecord($record);
    }
    function listAllDonations(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $rec= $this->GetDonationFromFileByID($arrayline[0]); 
            if($rec!=false)
            {
               $myreturn[$i] = $rec; 
            }
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
    function StoreDonation($fileManagerObj)
    {
        $id=$fileManagerObj->getLastId("~")+1;
        $record=$this->DonorId."~".$this->donationId."~".$this->donationName;
        $fileManagerObj->StoreRecordinFile($record);

    }
    function GetDonationFromFileByID($id){
        $r=new donation();
        $record=$this->fileManagerObj->getLineWithId($id); 
        $arrayline2=explode($this->fileManagerObj->Sperator,$record); 

       
            $r->DonorId= $arrayline2[0];
            $r->donationId= $arrayline2[1];
            $r->donationName=$arrayline2[2];
            $objDonationDetails=new DonationDetails();
            $AllDonations=array();
            $AllDonations=$objDonationDetails->listAllDonationsDetails();
            $j=0;
            for($i=0;$i<count($AllDonations);$i++){
                //echo$r->donationId;
               if($AllDonations[$i]->donationId==$r->donationId)
               {
                   // echo "done";
                    $r->ArrayOfDonationDetails[$j]=$AllDonations[$i];
                    //echo $ArrayOfDonationDetails[$j]->delivered;
                    $j++;
               }
    
            }
            return $r;

    }
       
    }

   
    class DonationDetails
    {
        public $donationId;
        public $userId;
        public $paymentMethod;
        public $typeOfdonation;
        public $amountOfdonation;
      public $delivered;
      public $dateOfDeliveredDAY;
      public $dateOfDeliveredMON;
      public $dateOfDeliveredYEAR;
      public $Time;
      public $howManyDays;
    
    public $fileManagerObj;
    function __construct()
    {
     $this->fileManagerObj=new FileManager();
     $this->fileManagerObj->FileName="DonationDetails.txt";
     $this->fileManagerObj->Sperator="~";
    }
    function UpdateDonationDetails($id, $obj){
        $OldRecord=$this->fileManagerObj->getLineWithId($id); 
        $NewRecord=$obj->donationId."~".$obj->userId."~".$obj->paymentMethod."~".$obj->typeOfdonation."~".$obj->amountOfdonation."~"."in progress"."~"."not delivered yet"."~".$obj->Time."\r\n";
        $this->fileManagerObj->UpdateRecored($this->FileName,$NewRecord,$OldRecord);
    }
    function deleteDonationDetails($id){
        $record=$this->fileManagerObj->getLineWithId($id); 
        $this->fileManagerObj->deleteRecord($record);
    }
    function listAllDonationsDetails(){
        $myreturn=array();
        $myfile=fopen($this->fileManagerObj->FileName,"r+") or die("unable to open file");
        $i=0;
        while(!feof($myfile))
        {
            $line=fgets($myfile);
            $arrayline=explode($this->fileManagerObj->Sperator,$line);
            $myreturn[$i] = $this->GetDonationDetailsFromFileByID($arrayline[0]); 
            $i++;
        }
        fclose($myfile);
        return $myreturn;
     }
    function StoreDonationDetails($fileManagerObj)
    {
        $id=$fileManagerObj->getLastId("~")+1;
         $record=$id."~".$this->userId."~".$this->paymentMethod . "~" . $this->typeOfdonation . "~" . $this->amountOfdonation."~"."in progress"."~". "not delivered yet"."~".$this->Time;
         $fileManagerObj->StoreRecordinFile($record);
    }
    
    function GetDonationDetailsFromFileByID($id){
        $r=new DonationDetails();
        $record=$this->fileManagerObj->getLineWithId($id); 
        $arrayline2=explode($this->fileManagerObj->Sperator,$record); 
        $r->donationId= $arrayline2[0];
        $r->userId=$arrayline2[1];
        $r->paymentMethod= $arrayline2[2];
        $r->typeOfdonation= $arrayline2[3];
        $r->amountOfdonation= $arrayline2[4];
        $r->delivered= $arrayline2[5];
        $r->dateOfDeliveredDAY= $arrayline2[6];
        $r->Time= $arrayline2[7];
        return $r;
    
    }
       
    }
    
   /*$obj= new donation();
   $h=$obj->GetDonationFromFileByID(2);
   echo $h->ArrayOfDonationDetails[0]->userId;*/



  
  /* $obj= new donation();
    $objg=$obj->GetDonationFromFileByID(2);
   echo $objg->ArrayOfDonationDetails[0]->userId;*/
   ?>