<div class="about">
         <div class="container">
            <div class="row d_flex">
               <div class="col-md-5">
                  <div class="titlepage">
                      <h2><a href=listProducts.php>PRODUCTS</a></h2>
                      <H3><table border =1>
    

   

</table>
    </form>
    </body>

</html>

</H3></p>
                   
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="about_img">
                 
                  </div>
               </div>
            </div>
         </div>
      </div>

    </div>
    
    