<?php 

include_once "Functions.php";
$donorObj=new donor();
$donorObj->deleteUser($_GET["Id"]);
header("location:User.php");

?>